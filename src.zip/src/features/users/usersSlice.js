"use strict";
//= ОБРАБОТКА СОСТОЯНИЙ pending (загрузка), fulfilled (успех), rejected (ошибка) =//
