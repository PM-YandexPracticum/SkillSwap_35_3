export interface LogoProps {
  size?: number;
  onClick?: () => void;
  className?: string;
}
