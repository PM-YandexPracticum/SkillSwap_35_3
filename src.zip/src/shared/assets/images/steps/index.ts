import LightBulbImage from './light-bulb.svg?react';
import SchoolBoardImage from './school-board.svg?react';
import UserInfoImage from './user-info.svg?react';

export { LightBulbImage, SchoolBoardImage, UserInfoImage };
