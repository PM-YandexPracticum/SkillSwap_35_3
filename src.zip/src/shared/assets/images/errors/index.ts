import Error404Image from './error-404.svg?react';
import Error500Image from './error-500.svg?react';

export { Error404Image, Error500Image };
