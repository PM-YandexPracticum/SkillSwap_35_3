import DoneIcon from './done.svg?react';

export { DoneIcon };
