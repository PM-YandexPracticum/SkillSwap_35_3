import EducationIcon from './book.svg?react';
import BusinessIcon from './briefcase.svg?react';
import LanguageIcon from './global.svg?react';
import HouseholdIcon from './home.svg?react';
import LifestyleIcon from './lifestyle.svg?react';
import ArtIcon from './palette.svg?react';

export {
  EducationIcon,
  BusinessIcon,
  LanguageIcon,
  HouseholdIcon,
  LifestyleIcon,
  ArtIcon
};
