import AddAvatarIcon from './add-avatar.svg?react';
import CalendarIcon from './calendar.svg?react';
import EyeIcon from './eye.svg?react';
import SearchIcon from './search.svg?react';

export { AddAvatarIcon, CalendarIcon, EyeIcon, SearchIcon };
