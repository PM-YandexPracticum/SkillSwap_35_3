import NotificationIcon from './notification.svg?react';

export { NotificationIcon };
