import UserCircleIcon from './user-circle.svg?react';
import LogoIcon from './logo.svg?react';

export { UserCircleIcon, LogoIcon };
