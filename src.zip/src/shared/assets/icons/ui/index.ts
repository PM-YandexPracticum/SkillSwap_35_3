import ArrorDownIcon from './chevron-down.svg?react';
import ArrorRightIcon from './chevron-right.svg?react';
import ArrorUpIcon from './chevron-up.svg?react';
import CrossIcon from './cross.svg?react';
import MoonIcon from './moon.svg?react';
import SortIcon from './sort.svg?react';

export {
  ArrorDownIcon,
  ArrorRightIcon,
  ArrorUpIcon,
  CrossIcon,
  MoonIcon,
  SortIcon
};
