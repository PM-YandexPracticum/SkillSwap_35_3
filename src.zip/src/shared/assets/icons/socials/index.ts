import AppleIcon from './apple.svg?react';
import GoogleIcon from './google.svg?react';

export { AppleIcon, GoogleIcon };
