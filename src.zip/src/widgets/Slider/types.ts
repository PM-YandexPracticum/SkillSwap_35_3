export interface SliderProps {
  className?: string;
  visible: number;
  children: React.ReactNode;
  buttonPosition?: 'edges' | 'inside';
}
