export interface CityFilterProps {
  onChange: (cities: string[]) => void;
  value: string[];
  cities: string[];
}
